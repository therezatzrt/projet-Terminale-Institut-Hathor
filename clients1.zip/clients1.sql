-- phpMyAdmin SQL Dump
-- version 3.2.1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mer 15 Janvier 2014 à 21:01
-- Version du serveur: 5.1.37
-- Version de PHP: 5.2.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Base de données :  `bddinstibeaute`
--

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(2) NOT NULL DEFAULT '0',
  `Nom_cli` varchar(20) DEFAULT NULL,
  `Pre_cli` varchar(20) DEFAULT NULL,
  `Rue_cli` varchar(50) DEFAULT NULL,
  `Ville_cli` varchar(10) DEFAULT NULL,
  `CP_cli` int(5) DEFAULT NULL,
  `Tel_cli` varchar(14) DEFAULT NULL,
  `codeTypeSoin` varchar(11) DEFAULT NULL,
    
  PRIMARY KEY (`id`),
  KEY `fkTypeSoin` (`codeTypeSoin`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38;

--
-- Contenu de la table `clients`
--

INSERT INTO `clients` (`id`, `Nom_cli`, `Pre_cli`, `Rue_cli`, `Ville_cli`, `CP_cli`, `Tel_cli`,`codeTypeSoin`) VALUES
(1, 'HURET', 'CAROLINE', 'Place de la République', 'LAMBALLE', '22400', '02 90 62 36 01','epilMail'),
(2, 'BEAUMONT', 'FRANCESCA', '2 rue du Fort Espagnol', 'LAMBALLE', '22400', '02 90 85 96 47','moust'),
(3, 'AUGER', 'ALEXANDRA', '25 rue des Genêts', 'LAMBALLE', '22400', '02 90 96 85 74','epilMail'),
(4, 'ARMAND', 'BARBARA', '17 Rue Barré', 'LAMBALLE', '22400', '06 25 14 65 98','epilMail'),
(5, 'SEBASSE', 'TINA', '17 rue Lauriers', 'LAMBALLE', '22400', '06 69 78 25 78','epilMail'),
(6, 'KARRER', 'PATRICIA', '26 rue Edouart Herriot', 'LAMBALLE', '22400', '06 87 58 47 58','epilMail'),
(7, 'GILLION', 'HULLA', '27 avenue Clémenceau', 'LAMBALLE', '22400', '02 90 48 58 02','epilMail'),
(8, 'ROMAIN', 'OLGA', '2 Place de la République', 'LAMBALLE', '22400', '02 90 45 87 45','moust'),
(9, 'BARLOM', 'JEANNE', '2 rue Philippe Le Gall', 'LAMBALLE', '22400', '06 98 25 12 41','epilMail'),
(10, 'BESNIER', 'STELLA', '12 de Keriboulo', 'LAMBALLE', '22400', '02 90 65 98 45','epilMail'),
(11, 'TIBHAR', 'ALEXA', '6 Rue Georges Brassens', 'LAMBALLE', '22400', '02 90 54 21 87','epilMail'),
(12, 'DONICAR', 'MICHELLE', '4 Place de la République', 'LAMBALLE', '22400', '06 35 95 84 75','moust'),
(13, 'DERTY', 'ALBERTA', '2 Av du Mar Foch', 'LAMBALLE', '22400', '06 02 05 04 05','epilMail'),
(14, 'GENT', 'LYDIE', 'Place de la république', 'LAMBALLE', '22400', '02 90 01 02 03','epilMail'),
(15, 'VERTU', 'MARIE', '427 avenue du maréchal Leclerc', 'LAMBALLE', '22400', '06 95 02 14 02','epilMail'),
(16, 'CHARGES', 'ISABELLE', '6 rue Kernormand', 'LAMBALLE', '22400', '06 85 20 54 15','epilMail'),
(17, 'SIMON', 'VALERIE', '2 rue St René', 'LAMBALLE', '22400', '06 98 32 65 45','epilMail'),
(18, 'QUEHEN', 'CORALIE', '20 avenue de la République', 'LAMBALLE', '22400', '06 98 78 52 85','moust'),
(19, 'EURIAL', 'FANNY', '55 Rue du Belzic', 'LAMBALLE', '22400', '06 32 87 85 96','epilMail'),
(20, 'MARTIN', 'ANTOINETTE', '12 rue Louis Billet', 'LAMBALLE', '22400', '09 26 23 54 26','epilMail'),
(21, 'CLEMENT', 'STEPHANIE', '6 rue Douet', 'LAMBALLE', '22400', '05 14 21 32 14','epilMail'),
(22, 'DETROIT', 'VALERIE', '6 rue Dakar', 'LAMBALLE', '22400', '09 69 47 14 22','epilMail'),
(23, 'MAROT', 'PIERRETTE', '2 Av du Géneral Leclerc', 'LAMBALLE','22400', '09 26 23 54 25','epilMail'),
(24, 'LAGOUTTE', 'MARTINE', '2 Rue Frédéric Chopin', 'LAMBALLE', '22400', '09 48 78 98 25','epilMail'),
(25, 'GARNIER', 'CHRISTINE', '7 Rue Peupliers', 'LAMBALLE', '22400', '09 69 87 14 25','moust'),
(26, 'DUPUIS', 'ALEXANDRA', '25 avenue de la république', 'LAMBALLE', '22400', '09 65 89 78 41','epilMail'),
(27, 'DUMAS', 'JEANNE', '2 Rue du Penher', 'LAMBALLE', '22400', '02 90 78 98 98','epilMail'),
(28, 'ROSAMOND', 'JESSICA', '15 Rue Henri Dunant', 'LAMBALLE', '22400', '06 25 04 85 01','epilMail'),
(29, 'MATISSE', 'NICOLE', '36 Rue du Père éternel', 'LAMBALLE', '22400', '02 90 98 24 15','epilMail'),
(30, 'NOULETTE', 'EMMANUELLE', '6 rue Vaillant', 'LAMBALLE', '22400', '02 99 25 47 25','epilMail'),
(31, 'RONK', 'CLAIRE', '16 Place de la République', 'LAMBALLE', '22400', '02 90 98 57 14','epilMail'),
(32, 'SOLARI', 'LAURENCE', '3 rue François Guhur', 'LAMBALLE', '22400', '06 85 96 74 01','moust'),
(33, 'WEIL', 'SABINE', '12 Rue Clémenceau', 'LAMBALLE', '22400', '06 19 74 85 96','epilMail'),
(34, 'SEGOURD', 'JULIETTE', '10 rue de Guerihuel', 'LAMBALLE', '22400', '07 32 65 98 65','epilMail'),
(35, 'BLET', 'MARTIE', '32 rue du parc', 'LAMBALLE', '22400', '06 98 25 14 02','epilMail'),
(36, 'HERTA', 'CLAUDINE', '5 Joseph Le Brix', 'LAMBALLE', '22400', '02 90 78 98 58','moust'),
(37, 'BACHET', 'MARIE', '30 rue Joseph Martin', 'LAMBALLE', '22400', '06 25 14 25 25','moust');

-- --------------------------------------------------------

--
-- Structure de la table `composer`
--

CREATE TABLE IF NOT EXISTS `composer` (
  `codeTypeSoin` INT(11) NOT NULL,
  `numSoin` int(11) NOT NULL,
  PRIMARY KEY (`codeTypeSoin`,`numSoin`),
  KEY `fkSoin` (`numSoin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `composer` 
--

-- --------------------------------------------------------

--
-- Structure de la table `soin`
--

CREATE TABLE IF NOT EXISTS `soin` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(60) NOT NULL,
   PRIMARY KEY (`num`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `soin`

-- --------------------------------------------------------

--
-- Structure de la table `reservation`
--

CREATE TABLE IF NOT EXISTS `reservation` (
  `code` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `idClients` int(11) NOT NULL,
  `dateSoin` date NOT NULL,
  `horaires` varchar(7) NOT NULL,
  `etat` varchar(30) NOT NULL,
  PRIMARY KEY (`code`),
  KEY `fkClients` (`idClients`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Contenu de la table `reservation`
--

INSERT INTO `reservation` (`code`, `date`, `idClients`, `dateSoin`, `horaires`, `etat`) VALUES
(1, '2019-01-12', 15, '2019-01-18', '09:00', 'provisoire'),
(2, '2019-01-12', 16, '2019-01-18', '09:30', 'provisoire'),
(3, '2019-01-12', 17, '2019-01-18', '10:00', 'provisoire'),
(4, '2019-01-13', 18, '2019-01-18', '11:00', 'provisoire'),
(5, '2019-01-13', 20, '2019-01-18', '14:00', 'provisoire'),
(6, '2019-01-13', 21, '2019-01-18', '15:00', 'provisoire'),
(7, '2019-01-13', 22, '2019-01-18', '16:00', 'provisoire'),
(8, '2019-01-13', 23, '2019-01-18', '16:00', 'provisoire'),
(9, '2019-02-12', 1, '2019-02-18', '09:00', 'provisoire'),
(10, '2019-02-12', 2, '2019-02-18', '09:30', 'provisoire'),
(11, '2019-02-12', 3, '2019-02-18', '10:00', 'provisoire'),
(12, '2019-02-13', 8, '2019-02-18', '11:00', 'provisoire'),
(14, '2019-02-13', 20, '2019-02-18', '14:00', 'provisoire'),
(15, '2019-02-13', 21, '2019-02-18', '15:00', 'provisoire'),
(16, '2019-02-13', 22, '2019-02-18', '16:00', 'provisoire');

-- --------------------------------------------------------

--
-- Structure de la table `typesoin`
--

CREATE TABLE IF NOT EXISTS `typeSoin` (
  `code` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(50) NOT NULL,
  `prix` float NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=4;

--
-- Contenu de la table `typeSoin`
--

INSERT INTO `typeSoin` (`code`, `libelle`, `prix`) VALUES
(1, 'epilation maillot', 40),
(2, 'moustache', 25),
(3, 'soin visage', 60) ;

-- --------------------------------------------------------

--
-- Contraintes pour la table `composer`
--
ALTER TABLE `composer`
  ADD CONSTRAINT `fkSoin` FOREIGN KEY (`numSoin`) REFERENCES `soin` (`num`),
  ADD CONSTRAINT `fkTypeSoin` FOREIGN KEY (`codeTypeSoin`) REFERENCES `typesoin` (`code`);


--
-- Contraintes pour la table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `fkClients` FOREIGN KEY (`idClients`) REFERENCES `clients` (`id`);
